SLEDOM! — PRESS KIT
Echo studio · version 5.8 · November 2026

IN SHORT
An arcade game where your worst enemy is you. Collect stars and don't touch your own echo:
every few seconds a copy of your hero appears and walks your path back and forth.
The longer you play, the more crowded your own past becomes.

FACTS
Title:        Sledom! (Russian: «Следом!»)
Developer:    Echo
Genre:        arcade, casual
Platforms:    browser on desktop and mobile (Playgama); Yandex Games coming soon;
              App Store, Google Play and RuStore planned
Price:        free
Languages:    English, Russian, Turkish, Spanish, Portuguese, German, French, Indonesian
Controls:     finger on phones; WASD or arrow keys on desktop

FEATURES
• Endless run: a new echo every 4 seconds, stars in a row build your combo.
• Daily Run: one map for everyone and a new rule every day; your first try counts and
  yesterday's ghost races beside you. Daily streaks earn rewards.
• 15 challenge levels with walls, blades and a hunter.
• A secret level suggested by a viewer in our YouTube comments.
• Skins and trails bought with stars, several visual themes.

LINKS
Play:     https://playgama.ai/play/a552jsp622x57z
Website:  https://echomaker.netlify.app
YouTube:  https://www.youtube.com/@echomaker
Boosty:   https://boosty.to/echodiary

WHAT'S INSIDE
screenshots/ru and screenshots/en — phone 1080×1920 and desktop 1920×1080
art/      — 512×512 icon, 800×470 covers and 1560×520 banners (ru and en), studio logo
video/    — 32 seconds of gameplay, 1280×720, no sound

USAGE
Feel free to use the screenshots, art and video in reviews, articles, videos and streams
about the game. A link to the game or our channel is appreciated.
Contact: via our YouTube channel @echomaker.
